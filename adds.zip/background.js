/*
Open a new tab, and load "my-page.html" into it.
*/
function getDomain(name){
switch (name) {
    case "Flipkart":
      return "http://www.flipkart.com/";
  case "Amazon":
	return "http://www.amazon.in/";
  case "Snapdeal":
	return "https://www.snapdeal.com/";

	}

}

function openMyPage(message) {
var domain = getDomain(message.name);
  chrome.tabs.create({
     "url": chrome.extension.getURL(domain)
   });
}






chrome.runtime.onMessage.addListener(openMyPage);

